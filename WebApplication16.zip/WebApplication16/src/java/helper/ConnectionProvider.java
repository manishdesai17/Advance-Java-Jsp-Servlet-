/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package helper;

import java.sql.*;

/**
 *
 * @author neelj
 */
public class ConnectionProvider {

    private static Connection con;

    public static Connection getConnection() {
        try {
            if (con == null) {

                // Load MySQL JDBC driver
                Class.forName("com.mysql.cj.jdbc.Driver");

                // Establish the Connection
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gvp", "root", "jalasakaro1234");
            }
        } catch (ClassNotFoundException e) {
            System.out.println("JDBC Driver not found.!!");
        } catch (SQLException e) {
            System.out.println("Connection failed.!!" + e.getMessage());
        }
        return con;
    }
}
