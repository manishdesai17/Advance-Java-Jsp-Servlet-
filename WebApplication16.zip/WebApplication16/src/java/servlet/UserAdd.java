/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UserDAO;
import entity.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.sql.SQLException;

/**
 *
 * @author neelj
 */
public class UserAdd extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fName = request.getParameter("firstName");
        String lName = request.getParameter("lastName");
        String city = request.getParameter("city");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");

        try {
            User user = new User(fName, lName, city, email, mobile);
            UserDAO udao = new UserDAO();
            boolean result = udao.addUser(user);
            if (result) {
                response.sendRedirect("user-list.jsp");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
