/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlet;

import dao.UserDAO;
import entity.User;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.sql.*;

/**
 *
 * @author neelj
 */
public class UserUpdate extends HttpServlet {
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String fName = request.getParameter("firstName");
        String lName = request.getParameter("lastName");
        String city = request.getParameter("city");
        String email = request.getParameter("email");
        String mobile = request.getParameter("mobile");
        HttpSession session = request.getSession();
        User user = (User) session.getAttribute("user");
        int id = user.getId();
        try {
            UserDAO udao = new UserDAO();
            boolean result = udao.updateUser(id, fName, lName, city, email, mobile);
            if (result) {
                response.sendRedirect("user-list.jsp");
            }
        } catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}
