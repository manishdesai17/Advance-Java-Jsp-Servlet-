
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LoginServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");

        String name = request.getParameter("name");
        HttpSession session = request.getSession();
         
        session.setMaxInactiveInterval(2000);
        // Store name and start time in session
        session.setAttribute("username", name);
        session.setAttribute("startTime", new Date());

        // Show the welcome page with session details
        showWelcomePage(response, session, name);
    }

    private void showWelcomePage(HttpServletResponse response, HttpSession session,
            String name) throws IOException {
        PrintWriter out = response.getWriter();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss"); // Format for date/time
        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy-MM-dd");

        // Convert session creation time to readable format
        String creationTime = sdf.format(new Date(session.getCreationTime()));
        String creationdate = sdf1.format(new Date(session.getCreationTime()));
        out.println("<!DOCTYPE html>");
        out.println("<html lang='en'>");
        out.println("<head>");
        out.println("<meta charset='UTF-8'>");
        out.println("<meta name='viewport' content='width=device-width, initial-scale=1.0'>");
        out.println("<title>Welcome</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<div>");
        out.println("<h1>Welcome, " + name + "!</h1>");
        out.println("<h3>Session Information:</h3>");
        out.println("<ul>");
         out.println("<li>Session ID: " + session.getId() + "</li>");
          out.println("<li>Session is New: " + session.isNew() + "</li>");
           out.println("<li>Session MaxInactiveInterval Time: " + session.getMaxInactiveInterval() + "</li>");
           out.println("<li>Session Hashcode: " + session.hashCode() + "</li>");
        out.println("<li>Session Creation Time: " + creationTime + "</li>");
         out.println("<li>Session Creation date: " + creationdate + "</li>");
        out.println("</ul>");
        out.println("<form action='LogoutServlet' method='post'>");
        out.println("<button type='submit'>Logout</button>");
        out.println("</form>");
        out.println("</div>");
        out.println("</body>");
        out.println("</html>");
    }
}
